import express from 'express';
import cors from 'cors';
const app=express(); app.use(cors()); app.use(express.json());
const services=[
 {id:'shirt',name:'Shirt',price:1500},{id:'trouser',name:'Trouser',price:1500},{id:'dress',name:'Dress',price:2500},{id:'suit',name:'Suit',price:5000},{id:'jacket',name:'Jacket',price:3000},{id:'bedsheet',name:'Bedsheet',price:3500}
];
const orders=[];
app.get('/health',(_,res)=>res.json({ok:true,app:'3GS Dry Cleaning'}));
app.get('/services',(_,res)=>res.json(services));
app.get('/orders',(_,res)=>res.json(orders));
app.post('/orders',(req,res)=>{const {customerId,items,address,pickupDate,pickupTime,paymentMethod}=req.body||{};if(!address||!items)return res.status(400).json({error:'address and items are required'});const total=Object.entries(items).reduce((s,[id,qty])=>s+(services.find(x=>x.id===id)?.price||0)*Number(qty),0);const order={id:`3GS-${1000+orders.length+1}`,customerId:customerId||'guest',items,address,pickupDate,pickupTime,paymentMethod:paymentMethod||'Pay on pickup',total,status:'pickup_requested',createdAt:new Date().toISOString()};orders.unshift(order);res.status(201).json(order);});
app.patch('/orders/:id/status',(req,res)=>{const o=orders.find(x=>x.id===req.params.id);if(!o)return res.status(404).json({error:'not found'});o.status=req.body.status;res.json(o);});
app.listen(process.env.PORT||3000,()=>console.log('3GS backend listening'));
