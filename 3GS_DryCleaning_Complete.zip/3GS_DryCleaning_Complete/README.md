# 3GS Dry Cleaning — v1 Complete Build

Dry-cleaning pickup and delivery app foundation for Android + iPhone.

## Included
- Customer app UI and order flow
- Google/Firebase authentication foundation
- Laundry item pricing and automatic totals
- Pickup address/date/time
- Order history and tracking
- Receipt and QR access screens
- Admin dashboard
- Express backend API foundation
- GitHub Actions Android build workflow
- Firebase `google-services.json` for package `com.threegs.app`

## Important
The project is prepared for cloud building. The local environment used to assemble this package does not have the Flutter SDK, so an APK was not compiled here. GitHub Actions is configured to build the Android APK after the repository is uploaded.

## Customer flow
Login → Home → Request pickup → Select clothes → Pickup details → Confirm → Track → Receipt/History.

## Business flow
New order → Assign pickup → Picked up → Cleaning → Ready → Out for delivery → Delivered.
