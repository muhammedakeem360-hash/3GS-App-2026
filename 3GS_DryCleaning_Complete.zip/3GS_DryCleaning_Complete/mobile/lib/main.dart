import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:qr_flutter/qr_flutter.dart';

const prices = <String, int>{
  'Shirt': 1500,
  'Trouser': 1500,
  'Dress': 2500,
  'Suit': 5000,
  'Jacket': 3000,
  'Bedsheet': 3500,
};

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(const ThreeGSApp());
}

class ThreeGSApp extends StatelessWidget {
  const ThreeGSApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: '3GS Dry Cleaning',
    theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.amber, scaffoldBackgroundColor: const Color(0xfffafafa)),
    home: const AuthGate(),
  );
}

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});
  @override
  Widget build(BuildContext context) => StreamBuilder<User?>(
    stream: FirebaseAuth.instance.authStateChanges(),
    builder: (_, snap) => snap.data == null ? const LoginPage() : const HomePage(),
  );
}

class LoginPage extends StatefulWidget { const LoginPage({super.key}); @override State<LoginPage> createState()=>_LoginPageState(); }
class _LoginPageState extends State<LoginPage> {
  bool busy=false;
  Future<void> login() async {
    setState(()=>busy=true);
    try {
      final account=await GoogleSignIn().signIn();
      if(account==null) return;
      final a=await account.authentication;
      await FirebaseAuth.instance.signInWithCredential(GoogleAuthProvider.credential(accessToken:a.accessToken,idToken:a.idToken));
    } catch(e) { if(mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Google login needs the Firebase Android setup.'))); }
    finally { if(mounted) setState(()=>busy=false); }
  }
  @override Widget build(BuildContext context)=>Scaffold(body:SafeArea(child:Center(child:SingleChildScrollView(padding:const EdgeInsets.all(28),child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[
    Container(width:96,height:96,decoration:BoxDecoration(color:Colors.amber,borderRadius:BorderRadius.circular(28)),child:const Icon(Icons.local_laundry_service,size:54)),
    const SizedBox(height:22), const Text('3GS',style:TextStyle(fontSize:48,fontWeight:FontWeight.w900)),
    const Text('Dry Cleaning • Pickup • Delivery'), const SizedBox(height:42),
    SizedBox(width:double.infinity,child:FilledButton.icon(onPressed:busy?null:login,icon:const Icon(Icons.login),label:Padding(padding:const EdgeInsets.all(15),child:Text(busy?'Signing in…':'Continue with Google')))),
  ]))));
}

class HomePage extends StatelessWidget { const HomePage({super.key});
  @override Widget build(BuildContext context){ final first=(FirebaseAuth.instance.currentUser?.displayName??'Customer').split(' ').first; return Scaffold(
    appBar:AppBar(title:const Text('3GS'),actions:[IconButton(onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const AccountPage())),icon:const Icon(Icons.person_outline))]),
    body:ListView(padding:const EdgeInsets.all(18),children:[
      Text('Hello, $first 👋',style:const TextStyle(fontSize:28,fontWeight:FontWeight.w800)), const SizedBox(height:5), const Text('Clean clothes. Easy pickup. Fast delivery.'), const SizedBox(height:20),
      Card(color:Colors.amber.shade100,child:Padding(padding:const EdgeInsets.all(20),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('Need dry cleaning?',style:TextStyle(fontSize:21,fontWeight:FontWeight.bold)),const SizedBox(height:8),const Text('We pick up from your home, clean your clothes and deliver them back.'),const SizedBox(height:16),FilledButton.icon(onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const BookingPage())),icon:const Icon(Icons.add),label:const Text('Request pickup'))]))),
      const SizedBox(height:18), const Text('Quick access',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),
      tile(context,Icons.receipt_long,'My orders','Order history',const OrdersPage()),tile(context,Icons.local_shipping_outlined,'Track order','Pickup to delivery',const TrackingPage()),tile(context,Icons.qr_code_2,'My QR','3GS customer QR',const QRPage()),
    ])); }
  Widget tile(BuildContext c,IconData i,String t,String s,Widget p)=>Card(child:ListTile(leading:CircleAvatar(child:Icon(i)),title:Text(t,style:const TextStyle(fontWeight:FontWeight.bold)),subtitle:Text(s),trailing:const Icon(Icons.chevron_right),onTap:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>p))));
}

class BookingPage extends StatefulWidget { const BookingPage({super.key}); @override State<BookingPage> createState()=>_BookingPageState(); }
class _BookingPageState extends State<BookingPage>{
  final address=TextEditingController(); DateTime? date; TimeOfDay? time; String payment='Pay on pickup';
  final items={for(final k in prices.keys) k:0};
  int get total=>items.entries.fold(0,(s,e)=>s+e.value*prices[e.key]!);
  @override void dispose(){address.dispose();super.dispose();}
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Request pickup')),body:ListView(padding:const EdgeInsets.all(18),children:[
    const Text('Select clothes',style:TextStyle(fontSize:22,fontWeight:FontWeight.bold)),...items.keys.map((k)=>Card(child:ListTile(title:Text(k),subtitle:Text('₦${prices[k]} each'),trailing:Row(mainAxisSize:MainAxisSize.min,children:[IconButton(onPressed:items[k]!>0?()=>setState(()=>items[k]=items[k]!-1):null,icon:const Icon(Icons.remove_circle_outline)),Text('${items[k]}'),IconButton(onPressed:()=>setState(()=>items[k]=items[k]!+1),icon:const Icon(Icons.add_circle_outline))])))),
    const SizedBox(height:8),TextField(controller:address,decoration:const InputDecoration(labelText:'Pickup address',border:OutlineInputBorder(),prefixIcon:Icon(Icons.location_on_outlined))),const SizedBox(height:12),
    Row(children:[Expanded(child:OutlinedButton.icon(onPressed:pickDate,icon:const Icon(Icons.calendar_month),label:Text(date==null?'Pickup date':'${date!.day}/${date!.month}/${date!.year}'))),const SizedBox(width:10),Expanded(child:OutlinedButton.icon(onPressed:pickTime,icon:const Icon(Icons.schedule),label:Text(time==null?'Pickup time':time!.format(context))))]),
    const SizedBox(height:12),DropdownButtonFormField<String>(value:payment,decoration:const InputDecoration(labelText:'Payment method',border:OutlineInputBorder()),items:const [DropdownMenuItem(value:'Pay on pickup',child:Text('Pay on pickup')),DropdownMenuItem(value:'Pay online',child:Text('Pay online'))],onChanged:(v)=>setState(()=>payment=v!)),
    const SizedBox(height:18),Card(child:Padding(padding:const EdgeInsets.all(18),child:Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[const Text('Estimated total',style:TextStyle(fontWeight:FontWeight.bold)),Text('₦$total',style:const TextStyle(fontSize:23,fontWeight:FontWeight.w900))]))),
    const SizedBox(height:14),FilledButton(onPressed:total==0||address.text.trim().isEmpty||date==null||time==null?null:()=>Navigator.pushReplacement(context,MaterialPageRoute(builder:(_)=>ConfirmationPage(total:total,address:address.text))),child:const Padding(padding:EdgeInsets.all(15),child:Text('Confirm pickup request'))),
  ]));
  Future<void> pickDate()async{final d=await showDatePicker(context:context,firstDate:DateTime.now(),lastDate:DateTime.now().add(const Duration(days:90)),initialDate:DateTime.now());if(d!=null)setState(()=>date=d);}
  Future<void> pickTime()async{final t=await showTimePicker(context:context,initialTime:TimeOfDay.now());if(t!=null)setState(()=>time=t);}
}

class ConfirmationPage extends StatelessWidget{final int total;final String address;const ConfirmationPage({super.key,required this.total,required this.address});@override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Order confirmed')),body:Center(child:Padding(padding:const EdgeInsets.all(25),child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[const Icon(Icons.check_circle,size:90,color:Colors.green),const SizedBox(height:20),const Text('Pickup request received',style:TextStyle(fontSize:25,fontWeight:FontWeight.bold)),const SizedBox(height:10),Text('Estimated total: ₦$total'),Text(address,textAlign:TextAlign.center),const SizedBox(height:25),FilledButton(onPressed:()=>Navigator.pushAndRemoveUntil(c,MaterialPageRoute(builder:(_)=>const TrackingPage()),(r)=>r.isFirst),child:const Text('Track order'))])));}

class OrdersPage extends StatelessWidget{const OrdersPage({super.key});@override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('My orders')),body:ListView(padding:const EdgeInsets.all(18),children:[Card(child:ListTile(leading:const CircleAvatar(child:Icon(Icons.local_laundry_service)),title:const Text('3GS Dry Cleaning'),subtitle:const Text('Latest order • Pickup requested'),trailing:const Text('Open'),onTap:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>const TrackingPage())))),const SizedBox(height:10),const Center(child:Text('Your completed orders will appear here.'))]);}

class TrackingPage extends StatelessWidget{const TrackingPage({super.key});@override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Track order')),body:ListView(padding:const EdgeInsets.all(22),children:[const Card(child:Padding(padding:EdgeInsets.all(16),child:Text('Order #3GS-1001 • Pickup requested'))),const SizedBox(height:15),...['Pickup requested','Picked up','Cleaning / washing','Ready','Out for delivery','Delivered'].asMap().entries.map((e)=>ListTile(leading:CircleAvatar(child:Text('${e.key+1}')),title:Text(e.value),subtitle:e.key==0?const Text('Current status'):null,trailing:e.key==0?const Icon(Icons.check_circle,color:Colors.green):const Icon(Icons.radio_button_unchecked))) ]));}

class QRPage extends StatelessWidget{const QRPage({super.key});@override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('My QR')),body:Center(child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[QrImageView(data:'https://3gs.example/customer',size:220),const SizedBox(height:18),const Text('3GS customer access',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),const Text('Final public link will replace the placeholder before launch.')])));}

class AccountPage extends StatelessWidget{const AccountPage({super.key});@override Widget build(BuildContext c){final u=FirebaseAuth.instance.currentUser;return Scaffold(appBar:AppBar(title:const Text('Account')),body:ListView(padding:const EdgeInsets.all(18),children:[ListTile(leading:const CircleAvatar(child:Icon(Icons.person)),title:Text(u?.displayName??'Customer'),subtitle:Text(u?.email??'')),const Divider(),const ListTile(leading:Icon(Icons.location_on_outlined),title:Text('Pickup address'),subtitle:Text('Manage your saved address')),ListTile(leading:const Icon(Icons.logout),title:const Text('Sign out'),onTap:()async{await FirebaseAuth.instance.signOut();await GoogleSignIn().signOut();if(c.mounted)Navigator.pop(c);})]));}}
